/*
 * ipStackGoodies.c
 *
 *  Created on: Aug 31, 2014
 *      Author: rhuertas
 */

#include "lwip/err.h"
#include "lwip/tcp.h"

#ifdef __arm__
extern volatile int TcpFastTimer;
extern volatile int TcpSlowTimer;
#endif
int transfer_data() {
#ifdef __arm__
	if (TcpFastTimer) {
		TcpFastTimer = 0;
		tcp_fasttmr();
	}
	if (TcpSlowTimer) {
		TcpSlowTimer = 0;
		tcp_slowtmr();
	}
#endif
	return 0;
}
