/*
 * base.h
 *
 *  Created on: Sep 3, 2014
 *      Author: rhuertas
 */

#ifndef BASE_H_
#define BASE_H_

#include "xparameters.h"


#define HTTP_PORT							80
#define APP_SITE_MEMORY_START_ADDR			(XPAR_MCB_DDR3_S0_AXI_BASEADDR+0x6000000U)
#define APP_SITE_MEMORY_MAX_SIZE			0x2000000U









#endif /* BASE_H_ */
