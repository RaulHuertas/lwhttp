

#ifndef LWBASICWSAPP_H_
#define LWBASICWSAPP_H_

#include "lwHTTPws.h"


#define BASICWSAPP_FLAGS_ALREADY_IN_USE 0x01U

struct lwHTTPDispatcher;
struct lwHTTPConnection;

struct BasicWSAppCtxt{
	unsigned int flags;
};

int basiWSApp_Register(struct lwHTTPDispatcher*);
//int basiWSApp_Register_HTTPS(struct lwHTTPSDispatcher*);

void basiWSApp_StartCtxt(struct BasicWSAppCtxt*);

int basiWSApp_ConnStarted(struct lwHTTPConnection*);
int basiWSApp_ConnRcvd(struct lwHTTPConnection*);
int basiWSApp_ConnFinished(struct lwHTTPConnection*);

int basiWSApp_ConnEvaluate();

#define BASICWSAPP_DEBUG_VERBOSE

#ifdef BASICWSAPP_DEBUG_VERBOSE
	#define BWSDebug(...) xil_printf( __VA_ARGS__)
#else
	#define BWSDebug(...)
#endif




#endif /* LWBASICWSAPP_H_ */
