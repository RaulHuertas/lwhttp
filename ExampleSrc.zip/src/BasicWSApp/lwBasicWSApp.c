
#include "lwBasicWSApp.h"
#include "lwHTTP.h"
#include "string.h"
#include "xparameters.h"
#include "xgpio_l.h"

//XGpio gpio;

unsigned int ledsOutput;
unsigned int buttonsInput;
char sb[64];
lwHTTPU8 sbl;

struct lwHTTPConnection* actualConn;

int basiWSApp_Register(struct lwHTTPDispatcher* disp){
	int registered = 0;
	int j;
	for(j = 0; j< LWHTTP_MAX_WS_PROTOCOLS;j++){
		if(disp->caps.wsProtocolsList.protocolsList[j].protocolName[0]==0){
			//espacio para registrar una aplicacion
			strcpy(
					disp->caps.wsProtocolsList.protocolsList[j].protocolName,
					"wsBasicApp"
			);
			disp->caps.wsProtocolsList.protocolsList[j].handler.startCB   = basiWSApp_ConnStarted;
			disp->caps.wsProtocolsList.protocolsList[j].handler.recvMsgCB = basiWSApp_ConnRcvd;
			disp->caps.wsProtocolsList.protocolsList[j].handler.endConnCB = basiWSApp_ConnFinished;
			registered = 1;
			break;
		}
	}
	if(registered){
		//XGpio_Initialize(&gpio, XPAR_LEDS_4BITS_DEVICE_ID);
		//XGpio_DiscreteWrite(&gpio, 0U, 0x0FU);
		ledsOutput = 0x00U;
		actualConn = 0U;
		XGpio_WriteReg(XPAR_LEDS_4BITS_BASEADDR, 0, ledsOutput);
	}
	return registered;
}

void basiWSApp_StartCtxt(struct BasicWSAppCtxt* ctxt){
	ctxt->flags = 0U;
}

int basiWSApp_ConnStarted(struct lwHTTPConnection* conn){
	BWSDebug("BWSDebug: Coneccion iniciada\n");
	struct BasicWSAppCtxt* ctxt = (struct BasicWSAppCtxt*)conn->subAppCtxt;
	if(ctxt->flags&BASICWSAPP_FLAGS_ALREADY_IN_USE){
		return -1;//No se puede aceptar mas de una conexion
	}
	ctxt->flags|=BASICWSAPP_FLAGS_ALREADY_IN_USE;
	actualConn = conn;
	//enviar estado actual de los botones
	buttonsInput = XGpio_ReadReg(XPAR_PUSH_BUTTONS_4BITS_BASEADDR, 0);
	sbl = sprintf(sb, "buttons: 0x%2.2x", buttonsInput);
	BWSDebug("BWSDebug: sending %s\n", sb);
	lwHTTPCtx_TxData(
		actualConn,
		sb,
		sbl,
		1
	);
	return 0;
}

int basiWSApp_ConnRcvd(struct lwHTTPConnection* conn){

	//struct lwHTTPwsContext* ctxt = &conn->webSocketContext;
	//struct lwHTTP_WSFrame* frame = &ctxt->frameBeingReceived;
	struct lwHTTP_WSMessage* msg = &conn->webSocketContext.msgRcvd;
	BWSDebug("BWSDebug: mensaje recibido %s\n", &msg->messageData[0]);
	msg->messageData[msg->payloadLength] = 0;
	if(strcmp((char*)&msg->messageData[0], "led1ON")==0){
		ledsOutput|=0x1U;
	}
	if(strcmp((char*)&msg->messageData[0], "led2ON")==0){
		ledsOutput|=0x2U;
	}
	if(strcmp((char*)&msg->messageData[0], "led3ON")==0){
		ledsOutput|=0x4U;
	}
	if(strcmp((char*)&msg->messageData[0], "led4ON")==0){
		ledsOutput|=0x8U;
	}
	if(strcmp((char*)&msg->messageData[0], "led1OFF")==0){
			ledsOutput&=~0x1U;
	}
	if(strcmp((char*)&msg->messageData[0], "led2OFF")==0){
			ledsOutput&=~0x2U;
	}
	if(strcmp((char*)&msg->messageData[0], "led3OFF")==0){
			ledsOutput&=~0x4U;
	}
	if(strcmp((char*)&msg->messageData[0], "led4OFF")==0){
			ledsOutput&=~0x8U;
	}
	XGpio_WriteReg(XPAR_LEDS_4BITS_BASEADDR, 0, ledsOutput);
	return 0;
}

int basiWSApp_ConnFinished(struct lwHTTPConnection* conn){
	struct BasicWSAppCtxt* ctxt = (struct BasicWSAppCtxt*)conn->subAppCtxt;
	BWSDebug("BWSDebug: conexion finalizada\n");
	ledsOutput = 0x00U;
	XGpio_WriteReg(XPAR_LEDS_4BITS_BASEADDR, 0, ledsOutput);
	actualConn = 0U;
	ctxt->flags&=~BASICWSAPP_FLAGS_ALREADY_IN_USE;
	return 0;
}

int basiWSApp_ConnEvaluate(){
	unsigned int nbi;
	if(!actualConn){//No hay que hacer nada
		return 0;
	}
	nbi = XGpio_ReadReg(XPAR_PUSH_BUTTONS_4BITS_BASEADDR, 0);
	if(nbi!=buttonsInput){
		sbl = sprintf(sb, "buttons: 0x%2.2x", nbi);
		BWSDebug("BWSDebug: sending %s\n", sb);
		lwHTTPCtx_TxData(
			actualConn,
			sb,
			sbl,
			1
		);
		buttonsInput = nbi;
	}

	return 0;
}

