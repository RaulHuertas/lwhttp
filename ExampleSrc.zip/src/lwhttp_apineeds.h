/*
 * lwhttp_apineeds.h
 *
 *  Created on: Sep 2, 2014
 *      Author: rhuertas
 */

#ifndef LWHTTP_APINEEDS_H_
#define LWHTTP_APINEEDS_H_



#define LWHTTP_MAX_CONN_TIMEOUT					(20U*50*1000U*1000U)




#define LWHTTP_MAX_URL_SIZE						127
#define LWHTTP_MAX_RESOURCES					256
#define LWHTTP_MAX_TUPLES						512
#define LWHTTP_MAX_ENTRYS						256

//#define LWHTTP_MAX_URL_SIZE						256


#define LWHTTP_USE_lwIP_STACK 				1


#endif /* LWHTTP_APINEEDS_H_ */
