/*
 * lwhttp_apineeds.c
 *
 *  Created on: Aug 31, 2014
 *      Author: rhuertas
 */
#include "lwHTTP.h"

#include "xtmrctr.h"
#include "platform.h"
#include "xsysace.h"
#include "sysace_stdio.h"
#include "base.h"

extern XTmrCtr timerObject;

inline lwHTTPU32 minimumOf(lwHTTPU32 a, lwHTTPU32 b){
	if(a<=b){
		return a;
	}else{
		return b;
	}
}

void lwHTTPDefaultGetTime( lwHTTPTime* actualTime){

	(*actualTime) = (lwHTTPTime)XTmrCtr_GetValue(&timerObject, 0);


}

int lwHTTPDefaulIsClientValidQ(
	struct lwHTTPDispatcherAcceptArguments* args
){
	return 0;
}



int lwHTTPSite_LoadFromFile(const char* filename, struct lwhttpSite* site){
	int ret = 0;
	int j;
	SYSACE_FILE* indexFile = sysace_fopen(filename, "r");
	if(indexFile == 0){
		ret = LOAD_SITE_ERROR_FILENOTFOUND;
		goto finalPoint;
	}
	sysace_fread(&(site->dataSize), 1, sizeof(site->dataSize), indexFile);
	sysace_fread(&(site->tupplesN), 1, sizeof(site->tupplesN), indexFile);
	sysace_fread(&(site->seed), 1, sizeof(site->seed), indexFile);
	sysace_fread(&(site->exportHomeFileIndex), 1, sizeof(site->exportHomeFileIndex), indexFile);
	sysace_fread(&(site->exportErrorFileIndex), 1, sizeof(site->exportErrorFileIndex), indexFile);
	xil_printf("site->dataSize: %d\n\r", 				site->dataSize);
	xil_printf("site->tupplesN: %d\n\r", 				site->tupplesN);
	xil_printf("site->seed: %d\n\r", 					site->seed);
	xil_printf("site->exportHomeFileIndex: %d\n\r", 	site->exportHomeFileIndex);
	xil_printf("site->exportErrorFileIndex: %d\n\r", 	site->exportErrorFileIndex);

	if(
			(	site->dataSize > ( APP_SITE_MEMORY_MAX_SIZE-sizeof(struct lwhttpSite) )	) ||
			(site->tupplesN >LWHTTP_MAX_TUPLES)
	){
		ret = LOAD_SITE_ERROR_FILETOOBIG;
		sysace_fclose(indexFile);
		goto finalPoint;
	}

	//Leer los datos
	//site->data = (char*)APP_SITE_MEMORY_START_ADDR;
	site->data = (char*)(APP_SITE_MEMORY_START_ADDR+sizeof(struct lwhttpSite));
	//j = sysace_fread(site->data, 1, site->dataSize, indexFile);
	lwHTTPU32 bytesReaded = 0;
	int bytesToRead = 0;
	//site->dataSize = 64;
	while(bytesReaded<site->dataSize){
		bytesToRead = minimumOf(200, site->dataSize-bytesReaded);
		j = sysace_fread( site->data+bytesReaded, 1, bytesToRead, indexFile);
		if(j<=0){
			break;
		}
		bytesReaded+=j;

	}
	LWHTTPDebug("bytesReaded: %8x \n\r", bytesReaded );
	if(bytesReaded!=site->dataSize){
		ret = LOAD_SITE_ERROR_READ_ERROR;
		sysace_fclose(indexFile);
		goto finalPoint;
	}
	sysace_fclose(indexFile);
	//site->tuples = (struct lwHTTPSiteTuple*)site->data;
	for(j = 0; j<site->tupplesN; j++){
	//for(j = 0; j<5; j++){

		site->tuples[j].urlHash = *((lwHTTPU32*)(site->data+site->tupplesN*0+j*4));
		site->tuples[j].position = *((lwHTTPU32*)(site->data+site->tupplesN*4+j*4));
		site->tuples[j].headerSize = *((lwHTTPU32*)(site->data+site->tupplesN*8+j*4));
		site->tuples[j].totalSize = *((lwHTTPU32*)(site->data+site->tupplesN*12+j*4));
		LWHTTPDebug("URL %d: \n\r", j);
		LWHTTPDebug("    urlHash: %8.8x \n\r", site->tuples[j].urlHash );
		LWHTTPDebug("    position: %d \n\r", site->tuples[j].position );
		LWHTTPDebug("    headerSize: %d \n\r", site->tuples[j].headerSize );
		LWHTTPDebug("    totalSize: %d \n\r", site->tuples[j].totalSize );
	}


	//Cerrar el archivo
	xil_printf("    Archivo cargado :D, bytes readed %8x\n\r", bytesReaded);

finalPoint:
	return ret;
}

