/*
 * Copyright (c) 2009-2013 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#include <stdio.h>

#include "xparameters.h"

#include "netif/xadapter.h"
#include "xtmrctr.h"
#include "platform.h"
#include "platform_config.h"
#ifdef __arm__
#include "xil_printf.h"
#endif

#include "lwHTTP.h"
#include "lwHTTP_SiteLoader.h"
#include "xsysace.h"
#include "sysace_stdio.h"
#include "shalib.h"
#include "base.h"
#include "lwHTTPws.h"
#include "BasicWSApp/lwBasicWSApp.h"


/* defined by each RAW mode application */
void print_app_header();
int start_application();
int transfer_data();

/* missing declaration in lwIP */
void lwip_init();

static struct netif server_netif;
struct netif *echo_netif;

void
print_ip(char *msg, struct ip_addr *ip) 
{
	print(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip), 
			ip4_addr3(ip), ip4_addr4(ip));
}

void
print_ip_settings(struct ip_addr *ip, struct ip_addr *mask, struct ip_addr *gw)
{

	print_ip("Board IP: ", ip);
	print_ip("Netmask : ", mask);
	print_ip("Gateway : ", gw);
}

XTmrCtr timerObject;
u32 currentTime;
XSysAce pCF;

/**Objetos para manejar la libreria lwHTTP*/
struct lwHTTPDispatcher lwHTTPDispatcherObject;
struct lwhttpSite* sitePackage = (struct lwhttpSite*)APP_SITE_MEMORY_START_ADDR;

void print_app_header()
{
	xil_printf("\n\r\n\r-----lwHTTP HTTP server, full software------\n\r");
}

int main()
{
	struct ip_addr ipaddr, netmask, gw;
	int fileLoadResult;
	/* the mac address of the board. this should be unique per board */
	unsigned char mac_ethernet_address[] = { 0x00, 0x0a, 0x35, 0x02, 0x2B, 0x3A };
	xil_printf("sizeof lwhttpSiteResult : %d\r\n", sizeof(struct lwhttpSite));
//	unsigned char shaTestString[] =	{ 'r', 'a', 'u', 'l', 0 };
//	Sha shaTest;
//	unsigned char shaTestResult[20];
//	int shaResult;
	echo_netif = &server_netif;

	init_platform();

	XTmrCtr_Initialize(&timerObject, XPAR_AXI_TIMER_0_DEVICE_ID);
	XTmrCtr_Stop(&timerObject,0);
	XTmrCtr_SetResetValue(&timerObject, 0, 0x00000000);
	XTmrCtr_Reset(&timerObject, 0);
	XTmrCtr_Start(&timerObject, 0);




	//shatest
	//shaResult = lwHTTP_CalculateSHA1(&shaTest, &shaTestString[0], 1, shaTestResult);
	XStatus s = XSysAce_Initialize(&pCF, XPAR_SYSACE_COMPACTFLASH_DEVICE_ID);
	if(s!=XST_SUCCESS	){
		xil_printf("Error inicializando la compact flash\n");
	}
	//Cargar archivo donde esta el sitio
	lwHTTPSite_Init(sitePackage);
	fileLoadResult = lwHTTPSite_LoadFromFile("site\\site.rhd", sitePackage);
	if(fileLoadResult!=0){
		xil_printf("Error leyendo la compact flash\n");
		return -1;
	}

	/* initliaze IP addresses to be used */
	IP4_ADDR(&ipaddr,  192, 168,   1, 10);
	IP4_ADDR(&netmask, 255, 255, 255,  0);
	IP4_ADDR(&gw,      192, 168,   1,  1);

	print_app_header();
	print_ip_settings(&ipaddr, &netmask, &gw);




  	/* Add network interface to the netif_list, and set it as default */
	if (!xemac_add(echo_netif, &ipaddr, &netmask,
						&gw, mac_ethernet_address,
						PLATFORM_EMAC_BASEADDR)) {
		xil_printf("Error adding N/W interface\n\r");
		return -1;
	}
	netif_set_default(echo_netif);

	/* Create a new DHCP client for this interface.
	 * Note: you must call dhcp_fine_tmr() and dhcp_coarse_tmr() at
	 * the predefined regular intervals after starting the client.
	 */
	/* dhcp_start(echo_netif); */

	/* now enable interrupts */
	platform_enable_interrupts();

	/* specify that the network if is up */
	netif_set_up(echo_netif);

	/**Inicializar la compact flash*/




	lwip_init();



	xil_printf("fileLoadResult: %d\r\n", fileLoadResult);
	xil_printf("lwhttp inicializando...\r\n");
	lwHTTPDispatcher_Init(&lwHTTPDispatcherObject, HTTP_PORT, sitePackage);
	xil_printf("lwhttp server listo en el puerto %d, esperando peticiones... ^.^ \r\n", HTTP_PORT);


	basiWSApp_Register(&lwHTTPDispatcherObject);



	/* receive and process packets */
	while (1) {
		xemacif_input(echo_netif);
		transfer_data();
		//currentTime = XTmrCtr_GetValue(&timerObject, 0);
		lwHTTPDispatcher_Evaluate(&lwHTTPDispatcherObject);
		basiWSApp_ConnEvaluate();
	}
  
	/* never reached */
	cleanup_platform();

	return 0;
}
